"""Helpers for links that must point to the Runner Bot.

The Creator Bot and Runner Bot intentionally use separate Telegram bot tokens.
Quiz play/deep-links must always target the Runner Bot, because that bot owns
/start and the quiz session handlers.
"""
from __future__ import annotations

import logging

import aiohttp

from . import config

logger = logging.getLogger(__name__)

_runner_username: str | None = None


async def get_runner_bot_username() -> str:
    """Return the Runner Bot username, resolved from RUNNER_BOT_TOKEN.

    We resolve it through Telegram's getMe API instead of requiring users to
    maintain a second username setting in .env. The value is cached for the
    lifetime of the process.
    """
    global _runner_username
    if _runner_username:
        return _runner_username
    token = config.RUNNER_BOT_TOKEN
    if not token:
        raise RuntimeError("RUNNER_BOT_TOKEN is not configured")

    url = f"https://api.telegram.org/bot{token}/getMe"
    timeout = aiohttp.ClientTimeout(total=15)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        async with session.get(url) as response:
            data = await response.json(content_type=None)
    if not data.get("ok") or not data.get("result", {}).get("username"):
        raise RuntimeError(f"Could not resolve Runner Bot username: {data}")
    _runner_username = data["result"]["username"]
    logger.info("Runner Bot resolved as @%s", _runner_username)
    return _runner_username


async def runner_start_url(qid: str) -> str:
    username = await get_runner_bot_username()
    return f"https://t.me/{username}?start={qid}"


async def runner_group_url(qid: str) -> str:
    username = await get_runner_bot_username()
    return f"https://t.me/{username}?startgroup={qid}"
