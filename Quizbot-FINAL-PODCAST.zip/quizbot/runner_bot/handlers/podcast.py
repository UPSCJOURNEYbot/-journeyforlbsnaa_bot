"""Podcast generation for Journey for लबासना.

Accepts a topic/text or a PDF. PDFs are automatically classified as either
MCQ/question material or study/content material. A single generation is
limited to 10 questions or 10 pages; custom selection accepts a comma-separated
list such as ``1,3,7,8,9,10,13`` (maximum 10 items).
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Any

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.constants import ParseMode
from telegram.ext import CallbackQueryHandler, CommandHandler, ContextTypes, MessageHandler, filters

from quizbot.shared import config
from quizbot.runner_bot.telegram_utils import safe_send_message
from quizbot.runner_bot.ai_providers import ai_generate

logger = logging.getLogger(__name__)

PODCAST_SESSIONS: dict[int, dict[str, Any]] = {}
MAX_SELECTION = 10
FEMALE_VOICE = "hi-IN-SwaraNeural"
MALE_VOICE = "hi-IN-MadhurNeural"

PROMO = (
    'Welcome to "Journey for लबासना" — aapka swagat hai! Ye sirf podcast nahi, '
    'UPSC preparation ko simple, practical aur memorable banane ki ek learning journey hai. '
    'Har topic ko context, real-life examples aur exam-oriented insights ke saath samjhiye. '
    'Chaliye, seekhte hain, samajhte hain aur लबासना ki journey ki taraf ek kadam aur badhate hain.'
)

SCRIPT_RULES = """
Create an educational two-host podcast in natural Hindi/Hinglish.
Hosts: [FEMALE] and [MALE]. Keep it conversational, clear, engaging and accurate.
The supplied source is authoritative for source-derived facts. Do not invent source claims.
Explain difficult terms immediately in simple language and add a clearly labelled real-life
example/analogy wherever it improves understanding. Connect relevant points to UPSC Prelims
and Mains without turning the podcast into a dry lecture.
Start with a natural 20–30 second brand intro in substance: welcome to "Journey for लबासना"; briefly say why this material/topic is important for UPSC and practical understanding.
Then explain why the selected material/topic matters for UPSC and practical understanding.
End with a concise recap and revision takeaways.
Return ONLY dialogue lines, one per line, prefixed [FEMALE] or [MALE].
"""

QUESTION_RULES = """
For EACH question, use this explanation sequence:
1) Read/restate what the question is testing.
2) State the correct answer (only when supported by the supplied material; otherwise reason it out transparently).
3) Explain the concept in depth but simple language.
4) Explain why EACH other option is wrong, not just the correct option.
5) Give the UPSC approach and elimination technique.
6) Add a memorable memory trick when useful.
7) Give a short revision note.
8) Give source/static-current-affairs linkage only when supported or clearly labelled as context.
Use real-life examples/analogies to make difficult concepts intuitive.
"""


def _selection_kb(uid: int, kind: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("✅ Default 10", callback_data=f"pod_default_{uid}_{kind}"),
         InlineKeyboardButton("✏️ Custom", callback_data=f"pod_custom_{uid}_{kind}")],
        [InlineKeyboardButton("❌ Cancel", callback_data=f"pod_cancel_{uid}")],
    ])


def _parse_selection(text: str, maximum: int) -> list[int]:
    text = text.strip().lower()
    if text in {"default", "all"}:
        return list(range(1, min(MAX_SELECTION, maximum) + 1))
    vals: list[int] = []
    for part in re.split(r"[,\s]+", text):
        if not part:
            continue
        if not part.isdigit():
            raise ValueError("Use numbers separated by commas, e.g. 1,3,7,8,9,10,13")
        n = int(part)
        if n < 1 or n > maximum:
            raise ValueError(f"Number {n} is outside 1-{maximum}")
        if n not in vals:
            vals.append(n)
    if not vals:
        raise ValueError("No selection supplied")
    if len(vals) > MAX_SELECTION:
        raise ValueError("Maximum 10 questions/pages per podcast")
    return vals


def _extract_pdf_pages(path: str) -> list[str]:
    import fitz
    doc = fitz.open(path)
    try:
        return [page.get_text("text") for page in doc]
    finally:
        doc.close()


def _looks_like_questions(text: str) -> bool:
    # Strong signals: numbered question stems plus option labels.
    qnums = len(re.findall(r"(?m)^\s*(?:Q(?:uestion)?\s*)?\d+\s*[.)\-:]\s+", text, re.I))
    opts = len(re.findall(r"(?m)^\s*[A-Da-d]\s*[.)\-:]\s+", text))
    answer = len(re.findall(r"(?im)^\s*(?:answer|correct answer|उत्तर|सही उत्तर)\s*[:：]", text))
    return (qnums >= 2 and opts >= 4) or (qnums >= 2 and answer >= 1)


def _extract_question_blocks(text: str) -> list[tuple[int, str]]:
    """Return (source question number, full question block)."""
    starts = list(re.finditer(r"(?m)^\s*(?:Q(?:uestion)?\s*)?(\d+)\s*[.)\-: ]\s+", text, re.I))
    if len(starts) < 2:
        # Fallback: preserve sequential numbering when a PDF has no clear numbering.
        blocks = [b.strip() for b in re.split(r"\n\s*\n", text) if b.strip()]
        return [(i, b) for i, b in enumerate(blocks, 1)]
    blocks: list[tuple[int, str]] = []
    seen: set[int] = set()
    for i, m in enumerate(starts):
        end = starts[i + 1].start() if i + 1 < len(starts) else len(text)
        block = text[m.start():end].strip()
        if not block:
            continue
        num = int(m.group(1))
        # Duplicate numbering can occur in headers/footers; keep the first real block.
        if num in seen:
            continue
        seen.add(num)
        blocks.append((num, block))
    return blocks


async def _generate_question_script(uid: int, questions: list[tuple[int, str]]) -> list[tuple[str, str]]:
    """Generate each question as a separately numbered segment so numbering is never skipped."""
    all_lines: list[tuple[str, str]] = []
    for qnum, question in questions:
        prompt = f"""
You are creating ONE segment of an educational UPSC podcast.
This segment is strictly for Question Number {qnum}.

MANDATORY AUDIO FLOW:
- First spoken line MUST clearly announce: "Ab hum Question Number {qnum} par aate hain."
- Then read/briefly restate the question so the listener knows exactly which question is being discussed.
- State the correct answer and explain it in depth.
- Explain why EACH other option is wrong.
- Give UPSC approach and elimination technique.
- Add a useful memory trick and a short revision note.
- Use a simple real-life example/analogy where helpful.
- Before ending this segment, clearly say that the discussion of Question Number {qnum} is complete.
- Do NOT discuss any other question.

{QUESTION_RULES}

Return ONLY dialogue lines prefixed [FEMALE] or [MALE].
Use natural Hindi/Hinglish, conversational Q&A between a female and male host.

SOURCE — QUESTION {qnum}:
{question}
"""
        raw = await ai_generate(uid, prompt, max_tokens=min(5000, max(2200, len(question) // 2)))
        lines = _parse_dialogue(raw)
        if not lines:
            raise RuntimeError(f"AI did not return valid dialogue for Question {qnum}.")
        # Hard guarantee of an audible question-number marker even if the model omits it.
        lines.insert(0, ("FEMALE", f"Ab hum Question Number {qnum} par aate hain."))
        lines.append(("MALE", f"Question Number {qnum} ki discussion yahin complete hoti hai."))
        all_lines.extend(lines)
    return all_lines

def _extract_tagged_questions(source: str) -> list[tuple[int, str]]:
    """Extract the exact question numbers selected by the PDF picker."""
    matches = list(re.finditer(r"(?ms)^\s*\[QUESTION\s+(\d+)\]\s*\n(.*?)(?=^\s*\[QUESTION\s+\d+\]\s*$|\Z)", source, re.I))
    if matches:
        return [(int(m.group(1)), m.group(2).strip()) for m in matches if m.group(2).strip()]
    return _extract_question_blocks(source)


def _script_prompt(source: str, mode: str, label: str) -> str:
    if mode == "question":
        task = (
            f"This is question material ({label}). Explain every selected question using the exact rule below.\n"
            f"{QUESTION_RULES}"
        )
    else:
        task = (
            f"This is study/content material ({label}). Explain all selected material in a coherent sequence, "
            "with context, mechanisms, consequences, examples and UPSC relevance."
        )
    return f"{SCRIPT_RULES}\n{task}\n\nSOURCE MATERIAL:\n{source}\n"


def _parse_dialogue(raw: str) -> list[tuple[str, str]]:
    out = []
    for line in raw.splitlines():
        m = re.match(r"\s*\[(FEMALE|MALE)\]\s*[:\-]?\s*(.+)", line, re.I)
        if m and m.group(2).strip():
            out.append((m.group(1).upper(), m.group(2).strip()))
    return out


async def _tts_and_merge(lines: list[tuple[str, str]], out_path: str) -> None:
    try:
        import edge_tts
    except ImportError as exc:
        raise RuntimeError("Podcast audio dependency is missing (edge-tts).") from exc
    work = Path(tempfile.mkdtemp(prefix="journey_podcast_", dir=str(config.TEMP_DIR)))
    try:
        files = []
        for i, (speaker, text) in enumerate(lines):
            p = work / f"{i:04d}.mp3"
            voice = FEMALE_VOICE if speaker == "FEMALE" else MALE_VOICE
            communicate = edge_tts.Communicate(text, voice=voice, rate="+0%", pitch="0Hz")
            await communicate.save(str(p))
            files.append(p)
        concat = work / "concat.txt"
        concat.write_text("".join(f"file '{p.as_posix().replace(chr(39), chr(39)+chr(92)+chr(39))}'\n" for p in files), encoding="utf-8")
        proc = await asyncio.create_subprocess_exec(
            "ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(concat), "-c", "copy", out_path,
            stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.PIPE,
        )
        _, err = await proc.communicate()
        if proc.returncode != 0:
            raise RuntimeError(f"Audio merge failed: {err.decode(errors='ignore')[-500:]}")
    finally:
        shutil.rmtree(work, ignore_errors=True)


async def _generate_podcast(uid: int, chat_id: int, ctx: ContextTypes.DEFAULT_TYPE, source: str, mode: str, label: str) -> None:
    status = await safe_send_message(ctx, chat_id, "🎙️ <b>Podcast script तैयार हो रहा है...</b>\nAI source ko explain + real-life examples ke saath convert kar raha hoon.", parse_mode=ParseMode.HTML)
    try:
        if mode == "question":
            raw_questions = _extract_tagged_questions(source)
            questions = raw_questions
            lines = await _generate_question_script(uid, questions)
        else:
            prompt = _script_prompt(source, mode, label)
            raw = await ai_generate(uid, prompt, max_tokens=min(12000, max(5000, len(source) // 2)))
            lines = _parse_dialogue(raw)
            if not lines:
                raise RuntimeError("AI did not return a valid two-host dialogue.")
        # Brand promo is spoken first, then the generated educational script.
        lines = [("FEMALE", PROMO)] + lines
        out = str(config.TEMP_DIR / f"podcast_{uid}_{os.getpid()}_{abs(hash(label)) % 10**8}.mp3")
        await _tts_and_merge(lines, out)
        if status:
            try:
                await status.edit_text("🎧 <b>Podcast तैयार है!</b>\n\n📚 Source explained with examples + UPSC-oriented understanding.", parse_mode=ParseMode.HTML)
            except Exception:
                pass
        with open(out, "rb") as fh:
            await ctx.bot.send_audio(chat_id=chat_id, audio=fh, title="Journey for लबासना — Podcast", performer="Journey for लबासना")
        os.remove(out)
    except Exception as exc:
        logger.exception("Podcast generation failed")
        if status:
            try:
                await status.edit_text(f"❌ Podcast generation failed: {str(exc)[:500]}")
            except Exception:
                pass


async def podcast_command(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    uid = update.effective_user.id
    chat_id = update.effective_chat.id
    PODCAST_SESSIONS.pop(uid, None)
    await safe_send_message(
        ctx, chat_id,
        "🎙️ <b>Journey for लबासना Podcast</b>\n\n"
        "Topic/text भेजें या PDF upload/reply करें.\n"
        "PDF में bot automatically पहचान लेगा कि यह <b>questions</b> हैं या <b>study content</b>.\n\n"
        "📌 एक podcast में अधिकतम <b>10 pages</b> या <b>10 questions</b> होंगे.\n"
        "✏️ Custom selection: <code>1,3,7,8,9,10,13</code> (अधिकतम 10).\n\n"
        "📣 हर podcast की शुरुआत 20–30 sec के Journey for लबासना intro से होगी.",
        parse_mode=ParseMode.HTML,
    )
    PODCAST_SESSIONS[uid] = {"step": "source", "chat_id": chat_id}


async def podcast_document(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    uid = update.effective_user.id
    sess = PODCAST_SESSIONS.get(uid)
    if not sess or sess.get("step") != "source" or not update.message or not update.message.document:
        return
    doc = update.message.document
    name = (doc.file_name or "").lower()
    if not name.endswith(".pdf"):
        await safe_send_message(ctx, update.effective_chat.id, "❌ Podcast source ke liye PDF upload करें, या text/topic भेजें.")
        return
    status = await safe_send_message(ctx, update.effective_chat.id, "📥 PDF पढ़ रहा हूँ और automatically questions/content detect कर रहा हूँ...")
    f = await ctx.bot.get_file(doc.file_id)
    data = await f.download_as_bytearray()
    path = config.TEMP_DIR / f"pod_source_{uid}_{os.getpid()}.pdf"
    path.write_bytes(bytes(data))
    try:
        pages = await asyncio.to_thread(_extract_pdf_pages, str(path))
        text = "\n\n".join(f"[PAGE {i+1}]\n{p}" for i, p in enumerate(pages))
        mode = "question" if _looks_like_questions(text) else "content"
        sess.update({"step": "select", "mode": mode, "pages": pages, "path": str(path)})
        kind = "question" if mode == "question" else "content"
        if status:
            await status.edit_text(
                f"🔎 <b>Detected:</b> {'Question PDF' if mode == 'question' else 'Study/Content PDF'}\n\n"
                f"📄 Total pages: <b>{len(pages)}</b>\n"
                f"{'❓ Detected questions: ' + str(len(_extract_question_blocks(text)) ) + ' | Default: first 10 questions' if mode == 'question' else '📖 Default: first 10 pages'}\n\n"
                "Custom के लिए <code>1,3,7,8,9,10,13</code> जैसे अधिकतम 10 numbers दें.",
                parse_mode=ParseMode.HTML, reply_markup=_selection_kb(uid, kind),
            )
    except Exception as exc:
        await safe_send_message(ctx, update.effective_chat.id, f"❌ PDF read failed: {str(exc)[:300]}")
        path.unlink(missing_ok=True)
        PODCAST_SESSIONS.pop(uid, None)


async def podcast_text(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    uid = update.effective_user.id
    sess = PODCAST_SESSIONS.get(uid)
    if not sess or sess.get("step") != "source" or not update.message or not update.message.text:
        return
    text = update.message.text.strip()
    if not text:
        return
    PODCAST_SESSIONS.pop(uid, None)
    await _generate_podcast(uid, update.effective_chat.id, ctx, text, "content", "topic/text")


async def podcast_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    q = update.callback_query
    await q.answer()
    parts = q.data.split("_")
    uid = int(parts[2])
    if q.from_user.id != uid:
        await q.answer("❌ Not your session", show_alert=True)
        return
    sess = PODCAST_SESSIONS.get(uid)
    if not sess:
        await q.message.edit_text("❌ Session expired. /podcast again")
        return
    action = parts[1]
    if action == "cancel":
        PODCAST_SESSIONS.pop(uid, None)
        await q.message.edit_text("❌ Podcast cancelled.")
        return
    mode = sess.get("mode", "content")
    if action == "default":
        if mode == "question":
            items = _extract_question_blocks("\n\n".join(sess.get("pages", [])))
            chosen = items[:10]
            source = "\n\n".join(f"[QUESTION {num}]\n{block}" for num, block in chosen)
            label = "questions " + ",".join(str(num) for num, _ in chosen)
        else:
            pages = sess.get("pages", [])
            selected = list(range(1, min(10, len(pages)) + 1))
            source = "\n\n".join(f"[PAGE {i}]\n{pages[i-1]}" for i in selected)
            label = f"pages {selected[0]}-{selected[-1]}"
        PODCAST_SESSIONS.pop(uid, None)
        await q.message.edit_text(f"✅ Selected default 10 {mode}s.\n🎙️ Generating...")
        await _generate_podcast(uid, q.message.chat_id, ctx, source, mode, label)
        return
    if action == "custom":
        sess["step"] = "custom"
        await q.message.edit_text(
            "✏️ Custom selection भेजें. उदाहरण: <code>1,3,7,8,9,10,13</code>\n"
            "अधिकतम 10 questions/pages.", parse_mode=ParseMode.HTML
        )


async def podcast_custom_text(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    uid = update.effective_user.id
    sess = PODCAST_SESSIONS.get(uid)
    if not sess or sess.get("step") != "custom" or not update.message or not update.message.text:
        return
    try:
        mode = sess.get("mode", "content")
        if mode == "question":
            items = _extract_question_blocks("\n\n".join(sess.get("pages", [])))
            available = {num: block for num, block in items}
            selected = _parse_selection(update.message.text, max(available) if available else 0)
            missing = [n for n in selected if n not in available]
            if missing:
                raise ValueError(f"Question number(s) {", ".join(map(str, missing))} PDF me nahi mile.")
            source = "\n\n".join(f"[QUESTION {num}]\n{available[num]}" for num in selected)
            label = "questions " + ",".join(map(str, selected))
        else:
            pages = sess.get("pages", [])
            selected = _parse_selection(update.message.text, len(pages))
            source = "\n\n".join(f"[PAGE {i}]\n{pages[i-1]}" for i in selected)
            label = "pages " + ",".join(map(str, selected))
    except ValueError as exc:
        await safe_send_message(ctx, update.effective_chat.id, f"❌ {exc}")
        return
    PODCAST_SESSIONS.pop(uid, None)
    await _generate_podcast(uid, update.effective_chat.id, ctx, source, mode, label)


def register(application) -> None:
    application.add_handler(CommandHandler("podcast", podcast_command))
    application.add_handler(CallbackQueryHandler(podcast_callback, pattern=r"^pod_(?:default|custom|cancel)_"))
    application.add_handler(MessageHandler(filters.Document.PDF, podcast_document))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, podcast_custom_text))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, podcast_text))
