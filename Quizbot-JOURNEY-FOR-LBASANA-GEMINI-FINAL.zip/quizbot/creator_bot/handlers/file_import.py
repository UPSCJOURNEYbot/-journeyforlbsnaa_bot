"""
Advance Quiz Bot — Open Source Project
This project was originally developed by Gagan (github.com/devgaganin).
Reference: https://t.me/advance_quiz_bot
The codebase has been reviewed and verified with the assistance of Claude AI.
"""

from __future__ import annotations

import json
import logging
from typing import Optional

from ..parsing import filter_words, parse_question_block, strip_source_noise

logger = logging.getLogger(__name__)


def _process_txt(content: str, remove_words: list[str], out_questions: list[dict]) -> int:
    """Parse a .txt upload using the same block-parsing engine as pasted
    text, plus the legacy `RT:`/`ID:`/`<ggn>...</ggn>` structured-field
    style for reply_text/file_id metadata."""
    ggn_blocks: list[str] = []

    def _replace_ggn(match) -> str:
        placeholder = f"GGN_PLACEHOLDER_{len(ggn_blocks)}"
        ggn_blocks.append(match.group(1))
        return f"RT: <ggn>{placeholder}</ggn>"

    import re

    protected = re.sub(r"<ggn>(.*?)</ggn>", _replace_ggn, content, flags=re.DOTALL)

    blocks = protected.strip().split("\n\n")
    processed = 0

    for block in blocks:
        if not block.strip():
            continue
        lines = block.strip().split("\n")
        has_structured = any(ln.strip().startswith(("RT:", "ID:")) for ln in lines)

        reply_text: Optional[str] = None
        file_id: Optional[str] = None
        core_lines = lines

        if has_structured:
            reply_text, file_id, core_lines = None, None, []
            for ln in lines:
                stripped = ln.strip()
                if stripped.startswith("RT:"):
                    rt_content = stripped[3:].strip()
                    ph_match = re.search(r"<ggn>GGN_PLACEHOLDER_(\d+)</ggn>", rt_content)
                    if ph_match:
                        idx = int(ph_match.group(1))
                        reply_text = ggn_blocks[idx] if idx < len(ggn_blocks) else rt_content
                    else:
                        reply_text = rt_content
                    if remove_words:
                        reply_text = filter_words(reply_text, remove_words)
                    reply_text = strip_source_noise(reply_text)
                elif stripped.startswith("ID:"):
                    file_id = strip_source_noise(stripped[3:].strip())
                else:
                    core_lines.append(ln)

        parsed = parse_question_block("\n".join(core_lines))
        if not parsed or isinstance(parsed["correct_option_id"], list):
            continue

        q_text = parsed["question"]
        opts = parsed["options"]
        exp = parsed.get("explanation")
        if remove_words:
            q_text = filter_words(q_text, remove_words)
            opts = [filter_words(o, remove_words) for o in opts]
            if exp:
                exp = filter_words(exp, remove_words)
        q_text = strip_source_noise(q_text)
        opts = [strip_source_noise(o) for o in opts]
        if exp:
            exp = strip_source_noise(exp)

        if not q_text or len(opts) < 2:
            continue

        out_questions.append(
            {
                "question": q_text, "options": opts,
                "correct_option_id": parsed["correct_option_id"],
                "explanation": exp, "reply_text": reply_text, "file_id": file_id,
            }
        )
        processed += 1

    return processed


def _process_json(raw: dict, remove_words: list[str], out_questions: list[dict]) -> int:
    """Parse the simple JSON schema:
    `{"questions": [{"question_text", "options": [{"id","text"}],
    "correct_option_id", "explanation"?, "reference_text"?, "file_id"?}]}`
    """
    questions = raw.get("questions")
    if not isinstance(questions, list):
        raise ValueError("'questions' should be an array.")

    processed = 0
    for q in questions:
        try:
            if not isinstance(q, dict):
                continue
            if not all(k in q for k in ("question_text", "options", "correct_option_id")):
                continue
            question_text = q["question_text"]
            if remove_words:
                question_text = filter_words(question_text, remove_words)
            question_text = strip_source_noise(question_text)

            options_data = q["options"]
            if not isinstance(options_data, list) or len(options_data) < 2:
                continue

            options: list[str] = []
            id_to_index: dict = {}
            for opt in options_data:
                if not isinstance(opt, dict) or "id" not in opt or "text" not in opt:
                    continue
                text = opt["text"]
                if remove_words:
                    text = filter_words(text, remove_words)
                text = strip_source_noise(text)
                if not text:
                    continue
                id_to_index[opt["id"]] = len(options)
                options.append(text)
            if len(options) < 2:
                continue

            correct_id = q["correct_option_id"]
            if correct_id not in id_to_index:
                continue
            correct_index = id_to_index[correct_id]

            explanation = q.get("explanation")
            if explanation and remove_words:
                explanation = filter_words(explanation, remove_words)
            if explanation:
                explanation = strip_source_noise(explanation)

            reply_text = q.get("reference_text")
            if reply_text and remove_words:
                reply_text = filter_words(reply_text, remove_words)
            if reply_text:
                reply_text = strip_source_noise(reply_text)

            out_questions.append(
                {
                    "question": question_text, "options": options,
                    "correct_option_id": correct_index, "explanation": explanation,
                    "reply_text": reply_text, "file_id": q.get("file_id"),
                }
            )
            processed += 1
        except Exception:
            logger.debug("Skipped malformed question in JSON import", exc_info=True)
            continue
    return processed



def _process_text_content(text: str, remove_words: list[str], out_questions: list[dict]) -> int:
    """Parse plain text/Markdown using the same tolerant MCQ parser."""
    return _process_txt(text, remove_words, out_questions)


def _process_pdf(content: bytes, remove_words: list[str], out_questions: list[dict]) -> tuple[int, int]:
    """Extract text from a PDF and parse it.

    If the PDF is scanned/image-only (or text extraction yields no valid
    questions), render pages and fall back to Tesseract OCR. Returns
    ``(processed, pages)``.
    """
    try:
        import fitz  # PyMuPDF
    except ImportError as exc:
        raise RuntimeError("PyMuPDF is required for PDF import") from exc

    doc = fitz.open(stream=content, filetype="pdf")
    pages = len(doc)
    pages_text: list[str] = []
    try:
        for page in doc:
            pages_text.append(page.get_text("text"))
        text = "\n\n".join(pages_text)
        before = len(out_questions)
        count = _process_text_content(text, remove_words, out_questions)
        if count:
            return count, pages

        # Scanned PDF fallback: OCR each page when normal extraction found
        # no parseable MCQs. This keeps normal PDFs fast while supporting
        # image-based study material.
        try:
            from PIL import Image
            import pytesseract
            from io import BytesIO
            ocr_pages: list[str] = []
            for page in doc:
                pix = page.get_pixmap(matrix=fitz.Matrix(2, 2), alpha=False)
                image = Image.open(BytesIO(pix.tobytes("png")))
                ocr_pages.append(pytesseract.image_to_string(image, lang="eng+hin"))
            ocr_text = "\n\n".join(ocr_pages)
            count = _process_text_content(ocr_text, remove_words, out_questions)
            if count:
                return count, pages
            del out_questions[before:]
            return 0, pages
        except Exception as exc:
            logger.warning("PDF OCR fallback unavailable: %s", exc)
            return 0, pages
    finally:
        doc.close()


def _process_image(content: bytes, remove_words: list[str], out_questions: list[dict]) -> int:
    """OCR an image when Tesseract is installed, then parse the OCR text."""
    try:
        from PIL import Image
        import pytesseract
        from io import BytesIO
        image = Image.open(BytesIO(content))
        text = pytesseract.image_to_string(image, lang="eng+hin")
    except Exception as exc:
        raise RuntimeError(
            "Image OCR unavailable. Install Pillow, pytesseract and the Tesseract OCR package."
        ) from exc
    return _process_text_content(text, remove_words, out_questions)


def _extract_html_text(html: str) -> str:
    """Extract useful text from public AI/share pages without executing JS."""
    from bs4 import BeautifulSoup
    soup = BeautifulSoup(html, "html.parser")
    for tag in soup(["script", "style", "noscript", "svg"]):
        tag.decompose()
    return soup.get_text("\n", strip=True)


async def process_public_url(
    url: str, out_questions: list[dict], remove_words: list[str]
) -> tuple[Optional[int], Optional[str]]:
    """Fetch a public text/AI share URL and parse its visible content.

    Works for public pages that expose their content in HTML. Dynamic/private
    pages may intentionally return no question text; the caller gets a clear
    error instead of silently accepting an empty import.
    """
    import aiohttp
    from urllib.parse import urlparse

    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        return None, "❌ Please send a valid public http/https link."
    try:
        timeout = aiohttp.ClientTimeout(total=25)
        headers = {"User-Agent": "Mozilla/5.0 (Quizbot Question Importer)"}
        async with aiohttp.ClientSession(timeout=timeout, headers=headers) as session:
            async with session.get(url, allow_redirects=True, max_redirects=5) as resp:
                if resp.status >= 400:
                    return None, f"❌ Link could not be opened (HTTP {resp.status})."
                ctype = (resp.headers.get("content-type") or "").lower()
                data = await resp.read()
        if "pdf" in ctype or url.lower().split("?", 1)[0].endswith(".pdf"):
            count, _ = _process_pdf(data, remove_words, out_questions)
        else:
            encoding = "utf-8"
            try:
                text = data.decode(encoding)
            except UnicodeDecodeError:
                text = data.decode("utf-8", errors="ignore")
            if "html" in ctype or "<html" in text[:1000].lower():
                text = _extract_html_text(text)
            count = _process_text_content(text, remove_words, out_questions)
        if not count:
            return 0, "❌ Link opened, but no valid MCQ questions were found. The AI share page may require login or JavaScript rendering."
        return count, None
    except Exception as exc:
        logger.exception("Public URL import failed: %s", url)
        return None, f"⚠️ Could not import this link: {exc}"

def process_uploaded_file(
    content: bytes, filename: str, out_questions: list[dict], remove_words: list[str]
) -> tuple[Optional[int], Optional[str]]:
    """Import .txt/.md/.markdown/.json/.pdf and common image files."""
    lower = (filename or "").lower().split("?", 1)[0]
    try:
        if lower.endswith(".json"):
            text = content.decode("utf-8")
            data = json.loads(text)
            if not isinstance(data, dict) or "questions" not in data:
                return None, "❌ Invalid JSON format. Expected an object with a 'questions' array."
            count = _process_json(data, remove_words, out_questions)
        elif lower.endswith((".txt", ".md", ".markdown")):
            text = content.decode("utf-8")
            count = _process_text_content(text, remove_words, out_questions)
        elif lower.endswith(".pdf"):
            count, _ = _process_pdf(content, remove_words, out_questions)
        elif lower.endswith((".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tif", ".tiff")):
            count = _process_image(content, remove_words, out_questions)
        else:
            return None, "❌ Supported question sources: TXT, MD, JSON, PDF, PNG/JPG/WEBP/BMP/TIFF, plain text, and public links."
        return count, None
    except UnicodeDecodeError:
        return None, "❌ Text file is not valid UTF-8."
    except json.JSONDecodeError as exc:
        return None, f"❌ Invalid JSON format: {exc}"
    except Exception as exc:
        logger.exception("process_uploaded_file failed for %s", filename)
        return None, f"⚠️ Error processing file: {exc}"

